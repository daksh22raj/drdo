from django import forms
from register.models import Team
from register.models import UserProfile
from core.models import CustomUser
from django.contrib.auth.forms import UserCreationForm

# class RegistrationForm(UserCreationForm):
#     email = forms.EmailField(label='E-mail', required=True)
#     company = forms.ModelChoiceField(queryset=Comp.objects.all())

#     class Meta:
#         model = CustomUser
#         fields = {
#             'first_name',
#             'last_name',
#             'email',
#             'user_type',
#             'company',
#             'password1',
#             'password2',
#         }

#         labels = {
#             'first_name': 'Name',
#             'last_name': 'Last Name',
#             'company': 'Company',
#         }

#     def save(self, commit=True):
#         user = super(RegistrationForm, self).save(commit=False)
#         user.first_name = self.cleaned_data['first_name']
#         user.last_name = self.cleaned_data['last_name']
#         user.email = self.cleaned_data['email']
#         company = self.cleaned_data['company']

#         if commit:
#             user.save()
#             user_profile = UserProfile.objects.create(user=user, company=Comp.objects.get(name=company))
#             user_profile.save()

#         return user

#     def __init__(self, *args, **kwargs):
#         super(RegistrationForm, self).__init__(*args, **kwargs)
#         # self.fields['username'].widget.attrs['class'] = 'form-control'
#         # self.fields['username'].widget.attrs['placeholder'] = 'Username'
#         self.fields['first_name'].widget.attrs['class'] = 'form-control'
#         self.fields['first_name'].widget.attrs['placeholder'] = 'First name'
#         self.fields['last_name'].widget.attrs['class'] = 'form-control'
#         self.fields['last_name'].widget.attrs['placeholder'] = 'Last name'
#         self.fields['email'].widget.attrs['class'] = 'form-control'
#         self.fields['email'].widget.attrs['placeholder'] = 'E-mail'
#         self.fields['password1'].widget.attrs['class'] = 'form-control'
#         self.fields['password1'].widget.attrs['placeholder'] = 'Password'
#         self.fields['password2'].widget.attrs['class'] = 'form-control'
#         self.fields['password2'].widget.attrs['placeholder'] = 'Retype Password'
#         self.fields['company'].widget.attrs['class'] = 'form-control'

class RegistrationForm(UserCreationForm):
    USER_TYPE_CHOICES = [
        ('PD', "Project Director"),
        ('SD', "Scientist 'D' or Above"),
        ('SC', "Scientist 'C' or Below"),
    ]
    
    user_type = forms.ChoiceField(choices=USER_TYPE_CHOICES, required=True, label="User Type")
    
    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'email', 'password1', 'password2', 'user_type']
        
    def save(self, commit=True):
        user = super().save(commit=False)
        user.user_type = self.cleaned_data['user_type']
        if commit:
            user.save()
        return user

    def __init__(self, *args, **kwargs):
        super(RegistrationForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs['class'] = 'form-control'
        self.fields['first_name'].widget.attrs['placeholder'] = 'First name'
        self.fields['last_name'].widget.attrs['class'] = 'form-control'
        self.fields['last_name'].widget.attrs['placeholder'] = 'Last name'
        self.fields['email'].widget.attrs['class'] = 'form-control'
        self.fields['email'].widget.attrs['placeholder'] = 'E-mail'
        self.fields['password1'].widget.attrs['class'] = 'form-control'
        self.fields['password1'].widget.attrs['placeholder'] = 'Password'
        self.fields['password2'].widget.attrs['class'] = 'form-control'
        self.fields['password2'].widget.attrs['placeholder'] = 'Retype Password'
        # self.fields['company'].widget.attrs['class'] = 'form-control'
    
class TeamRegistrationForm(forms.ModelForm):
    # name = forms.CharField(max_length=80)
    # email = forms.EmailField()
    # members = forms.ModelMultipleChoiceField(queryset=CustomUser.objects.all(), widget=forms.CheckboxSelectMultiple, required=False)
    class Meta:
        model = Team
        fields = ['name', 'email', 'members']


    # def save(self, commit=True):
    #     team = Team()
    #     Team.name = self.cleaned_data['name']
    #     Team.email = self.cleaned_data['email']
    #     Team.members = self.cleaned_data['members']

    #     if commit:
    #         Team.save(self)


    def __init__(self, *args, **kwargs):
        super(TeamRegistrationForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['class'] = 'form-control'
        self.fields['name'].widget.attrs['placeholder'] = 'Name'
        self.fields['email'].widget.attrs['class'] = 'form-control'
        self.fields['email'].widget.attrs['placeholder'] = 'Email'
        self.fields['members'].widget.attrs['class'] = 'form-control'
        self.fields['members'] .widget.attrs['placeholder'] = 'Members'


class ProfilePictureForm(forms.Form):
    img = forms.ImageField()
    class Meta:
        model = UserProfile
        fields = ['img']

    def save(self, request, commit=True):
        user = request.user.userprofile_set.first()
        user.img = self.cleaned_data['img']

        if commit:
            user.save()

        return user

    def __init__(self, *args, **kwargs):
        super(ProfilePictureForm, self).__init__(*args, **kwargs)
        self.fields['img'].widget.attrs['class'] = 'custom-file-input'
        self.fields['img'].widget.attrs['id'] = 'validatedCustomFile'

class AddMembersForm(forms.ModelForm):
    members = forms.ModelMultipleChoiceField(queryset=CustomUser.objects.filter(user_type__in=['SD', 'SC']), required=False, widget=forms.CheckboxSelectMultiple, label="Select Team Members")

    class Meta:
        model = Team
        fields = ['members']

    def __init__(self, *args, **kwargs):
        super(AddMembersForm, self).__init__(*args, **kwargs)
        self.fields['members'].queryset=CustomUser.objects.filter(user_type__in=['SD', 'SC'])