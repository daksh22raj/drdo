from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden
from django.contrib.auth import login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from projects.models import Task
from projects.views import *
from core.models import *
from .models import *
from .forms import RegistrationForm, TeamRegistrationForm, ProfilePictureForm, AddMembersForm

CustomUser = get_user_model()

# Create your views here.
def register(request):
	if request.method == 'POST':
		form = RegistrationForm(request.POST)
		context = {'form':form}
		
		
		if form.is_valid():
			user = form.save(commit=False)
			user.user_type = form.cleaned_data['user_type'] # Set user type
			user.save()
			created = True
			login(request, user, backend='django.contrib.auth.backends.ModelBackend')
			context = {'created' : created}
		return render(request, 'register/reg_form.html', context)
	

	else:
		form = RegistrationForm()
		context = {
			'form' : form,
		}
		return render(request, 'register/reg_form.html', context)

def register_pd(request):
	if request.method == 'POST':
		form = RegistrationForm(request.POST)
		if form.is_valid():
			user=form.save(commit=False)
			user.user_type = 'PD'
			user.save()
			created=True
			login(request, user)
			context = {'created': created}
			return redirect('pd_dashboard')
		else:
			return render(request, 'register/register_pd.html', context)
	else:
		form = RegistrationForm()
		context = {
			'form': form,
		}
		return render(request, 'register/register_pd.html', {'form':form})

def register_sd(request):
	if request.method == 'POST':
		form = RegistrationForm(request.POST)
		if form.is_valid():
			user=form.save(commit=False)
			user.user_type = 'SD'
			user.save()
			created=True
			login(request, user)
			return redirect('sd_dashboard')
		else:
			return render(request, 'register/register_sd.html', {'created': created})
	else:
		form=RegistrationForm()
	return render(request, 'register/register_sd.html', {'form':form})

def register_sc(request):
	if request.method == 'POST':
		form = RegistrationForm(request.POST)
		if form.is_valid():
			user=form.save(commit=False)
			user.user_type = 'SC'
			user.save()
			created=True
			login(request, user)
			return redirect('projects:sc_task_list')
		else:
			return render(request, 'register/register_sc.html', {'created': created})
	else:
		form=RegistrationForm()
	return render(request, 'register/register_sc.html', {'form':form})

@login_required
def usersView(request):
	# if request.user.user_type == 'PD':
	if request.method == 'POST':
		users = UserProfile.objects.all()
		tasks = Task.objects.all()
		context = {
			'users': users,
			'tasks': tasks,
		}
		return render(request, 'register/users.html', context)
	# else:
	#     return HttpResponseForbidden("Only Project Directors can view users.")
	return render(request, 'register/users.html')

@login_required
def user_view(request, profile_id):
	user = UserProfile.objects.get(id=profile_id)
	context = {
		'user_view' : user,
	}
	return render(request, 'register/user.html', context)


@login_required
def profile(request):
	if request.method == 'POST':
		img_form = ProfilePictureForm(request.POST, request.FILES)
		print('PRINT 1: ', img_form)
		context = {'img_form' : img_form }
		if img_form.is_valid():
			img_form.save(request)
			updated = True
			context = {'img_form' : img_form, 'updated' : updated }
			return render(request, 'register/profile.html', context)
		else:
			return render(request, 'register/profile.html', context)
	else:
		img_form = ProfilePictureForm()
		context = {'img_form' : img_form }
		return render(request, 'register/profile.html', context)

@login_required
def newTeam(request):
	if request.method == 'POST':
		form = TeamRegistrationForm(request.POST)
		context = {'form':form}
		if form.is_valid():
			form.save()
			created = True
			form = TeamRegistrationForm()
			context = {
				'created' : created,
				'form' : form,
					   }
			return render(request, 'register/new_team.html', context)
		else:
			return render(request, 'register/new_team.html', context)
	else:
		form = TeamRegistrationForm()
		context = {
			'form' : form,
		}
		return render(request, 'register/new_team.html', context)

@login_required
def create_teams_for_project(request, project_id):
	project = get_object_or_404(Project, id=project_id)
	TeamFormSet = modelformset_factory(Team, form=TeamRegistrationForm, extra=3) # 3 teams by default

	if request.method == 'POST':
		formset = TeamRegistrationForm(request.POST)
		if formset.is_valid():
			teams = formset.save(commit=False)
			for team in teams:
				project.teams.add(team) # Assuming M2M relation
			return redirect('project_detail', project_id=project.id)
		else:
			formset = TeamFormSet(queryset=Team.objects.none())
	return render(request, 'register/create_teams_for_project.html', {'formset':formset, 'project':project})

@login_required
def add_team_members(request, team_id):
	team=get_object_or_404(Team, id=team_id)
	# users = CustomUser.objects.exclude(id__in=team.members.all())

	if request.method == 'POST':
		# selected_members = request.POST.getlist('members')
		form = AddMembersForm(request.POST, instance=Team)

		if form.is_valid():
			form.save()
			return redirect('team_detail', team_id=team.id)
		else:
			form = AddMembersForm(instance=team)
	return render(request, 'register/add_members.html', {'form':form, 'team':team})
	# 	for user_id in selected_members:
	# 		user = CustomUser.objects.get(id=user_id)
	# 		team.members.add(user)
	# 	return redirect('team_detail', team_id=team.id)
	
	# return render(request, 'register/add_members.html', {'team': team, 'users': users})
	# users = CustomUser.objects.all()
	# return render(request, 'register/add_team_members.html',  {'team': team, 'users': users})

@login_required
def update_team(request, team_id):
	team = get_object_or_404(Team, id=team_id)
	form = TeamRegistrationForm(request.POST or None, instance=team)
	if form.is_valid():
		form.save()
		return redirect('team_detail', team_id=team.id)
	return render(request, 'register/update_team.html', {'form': form})

@login_required
def delete_team(request, team_id):
	team = get_object_or_404(Team, id=team_id)
	if request.method == 'POST':
		team.delete()
		return redirect('team_list')
	return render(request, 'register/delete_team.html', {'team': team})

@login_required
def assign_team_to_project(request, project_id, team_id):
	project = get_object_or_404(Project, id=project_id)
	teams = get_object_or_404(Team, id=team_id)
	if request.method == 'POST':
		team_ids = request.POST.getlist('teams')
		project.teams.set(team_ids)
		return redirect('project_detail', project_id=project.id)

		teams=Team.object.all()
	return render(request, 'projects/assign_teams.html', {'project': project, 'teams': teams})

# Analytics View
@login_required
def team_performance(request, team_id):
	team = get_object_or_404(Team, id=team_id)
	tasks = Task.objects.filter(assigned_team=team)
	total_tasks = tasks.count()
	completed_tasks = tasks.filter(status='Completed').count()
	delayed_tasks = tasks.filter(status='Delayed').count()
	context = {
			'team': team,
			'total_tasks': total_tasks,
			'completed_tasks': completed_tasks,
			'delayed_tasks': delayed_tasks,
		}
	return render(request, 'register/team_performance.html', context)

@login_required
def team_list(request):
	teams = Team.objects.all()
	return render(request, 'register/team_list.html', {'teams': teams})

@login_required
def team_detail(request, team_id):
	team = get_object_or_404(Team, id=team_id)
	members = team.members.all()
	projects = Project.objects.filter(team=team)
	return render(request, 'register/team_detail.html', {'team': team, 'members': members, 'projects': projects})

@login_required
def pd_view_teams(request):
	teams = Team.objects.select_related('created_by').prefetch_related('members', 'projects')  # Optional: Filter by PD later
	user_types = dict(CustomUser.USER_TYPES)
	return render(request, 'register/pd_view_teams.html', {'teams': teams, 'user_types': user_types})

# Invites & Friends views
# def invites(request):
# 	return render(request, 'register/invites.html')

# def invite(request, profile_id):
# 	profile_to_invite = UserProfile.objects.get(id=profile_id)
# 	logged_profile = get_active_profile(request)
# 	if not profile_to_invite in logged_profile.friends.all():
# 		logged_profile.invite(profile_to_invite)
# 	return redirect('core:index')

# def deleteInvite(request, invite_id):
# 	logged_user = get_active_profile(request)
# 	logged_user.received_invites.get(id=invite_id).delete()
# 	return render(request, 'register/invites.html')

# def acceptInvite(request, invite_id):
# 	invite = Invite.objects.get(id=invite_id)
# 	invite.accept()
# 	return redirect('register:invites')

# def remove_friend(request, profile_id):
# 	user = get_active_profile(request)
# 	user.remove_friend(profile_id)
# 	return redirect('register:friends')

# def get_active_profile(request):
# 	user_id = request.user.userprofile_set.values_list()[0][0]
# 	return UserProfile.objects.get(id=user_id)

# def friends(request):
# 	if request.user.is_authenticated:
# 		user = get_active_profile(request)
# 		friends = user.friends.all()
# 		context = {
# 			'friends' : friends,
# 		}
# 	else:
# 		users_prof = UserProfile.objects.all()
# 		context= {
# 			'users_prof' : users_prof,
# 		}
# 	return render(request, 'register/friends.html', context)