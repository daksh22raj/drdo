from django.urls import path
from . import views
from core.views import *
from register.views import *

app_name = 'register'

urlpatterns = [
    path('new-user/', views.register, name='new-user'),
    path('new-team/', views.newTeam, name='new-team'),
    path('users/', views.usersView, name='users'),
    path('users/profile', views.profile, name='profile'),
    path('users/<int:profile_id>/', views.user_view, name='user'),
    path('register/pd/', views.register_pd, name='register-pd'),
	path('register/sd/', views.register_sd, name='register-sd'),
	path('register/sc/', views.register_sc, name='register-sc'),
    path('teams/create/<int:project_id>/', views.create_teams_for_project, name='create_teams_for_project'),
	path('teams/assign-members/<int:team_id>/', views.add_team_members, name='add_teams_members'),
	path('teams/performance/<int:team_id>/', views.team_performance, name='team_performance'),
    path('teams/', views.team_list, name='team_list'),
    path('teams/<int:team_id>/', views.team_detail, name='team_detail'),
    path('dashboard/teams/', views.pd_view_teams, name='pd_view_teams'),
    path('assign-project-to-team/', views.assign_team_to_project, name='assign_project_to_team'),
    path('add_team_members/', views.add_team_members, name='add_team_members'),


    # urls not in used
    # path('users/invite/<int:profile_id>/', views.invite, name='invite'),
    # path('users/invites/', views.invites, name='invites'),
    # path('users/invites/accept/<int:invite_id>/', views.acceptInvite, name='accept-invite'),
    # path('users/invites/delete/<int:invite_id>/', views.deleteInvite, name='delete-invite'),
    # path('users/friends/', views.friends, name='friends'),
    # path('users/friends/remove/<int:profile_id>/', views.remove_friend, name='remove-friend'),
]