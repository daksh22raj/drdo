from django.contrib import admin
from .models import *


class TeamAdmin(admin.ModelAdmin):
    list_display = ['name','email']
    filter_horizontal = ['members',] # shows members selection box 
    search_fields = ['name']

class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'team',]

# class InviteAdmin(admin.ModelAdmin):
#     list_display = ['inviter', 'invited',]
#     search_fields = ['inviter', 'invited',]

# Register your models here.
admin.site.register(Team, TeamAdmin)
admin.site.register(UserProfile, UserProfileAdmin)
# admin.site.register(Invite, InviteAdmin)