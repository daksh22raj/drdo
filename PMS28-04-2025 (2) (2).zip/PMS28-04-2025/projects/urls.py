from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

app_name = 'projects'

urlpatterns = [
    path('', views.projects, name='projects'),
    path('new-project/', views.newProject, name='new-project'),
    path('new-task/', views.newTask, name='new-task'),
    path('assign-task/', views.assign_task, name='assign_task'),
    path('performance/', views.view_team_performance, name='view_team_performance'),
    path('tasks/', views.view_my_tasks, name='view_my_tasks'),
    path('tasks/status/', views.view_task_status, name='view_task_status'),
    # path('tasks/my_tasks/', views.my_tasks, name='my_tasks'),
    path('my-tasks/', views.sc_tasks_list, name='sc_task_list'),
    path('team-tasks/', views.sd_task_list, name='sd_task_list'),
    path('task/<int:task_id>/', views.task_detail, name='task-detail'),
    path('task/update/<int:task_id>/', views.edit_task, name='edit-task'),
    path('pd/task/list/', views.pd_task_list, name='pd_task_list'),
    path('pd/task/<int:task_id>/', views.pd_task_detail, name='pd_task_detail'),
    path('pd/task/update/<int:task_id>', views.pd_edit_task, name='pd_edit_task'),
    path('task/<int:task_id>/complete/', views.mark_task_completed, name='mark_task_completed'),
    path('tasks/red-alert/', views.red_alert_tasks, name='red_alert_tasks'),

    
    # Team performance views
    path('team/performance/', views.view_team_performance, name='view_team_performance'),
    path('team/performance/<str:user_type>/', views.view_filtered_performance, name='view_filtered_performance'),
]