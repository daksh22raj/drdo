from django import forms
from django.forms import modelformset_factory, inlineformset_factory
from django.utils.text import slugify
from django.db.models import QuerySet
from .models import *
from register.models import Team
from core.models import CustomUser
from django.contrib.auth import get_user_model

User = get_user_model()
# from django.contrib.auth.models import User

status = (
    ('Select Status', 'Select Status'),
    ('In Progress', 'In Progress'),
    ('Completed', 'Completed'),
)

due = (
    ('On Due', 'On Due'),
    ('Overdue', 'Overdue'),
    ('Completed', 'Completed'),
)


class TaskRegistrationForm(forms.ModelForm):
    project = forms.ModelChoiceField(queryset=Project.objects.all())
    assign = forms.ModelMultipleChoiceField(queryset=CustomUser.objects.all(), widget=forms.SelectMultiple, required=True)
    task_name = forms.CharField(max_length=80)
    status = forms.ChoiceField(choices=due)
    progress = forms.FloatField(min_value=0, max_value=100)
    # due = forms.ChoiceField(choices=due)

    class Meta:
        model = Task
        fields = ['project', 'assign', 'task_name', 'status', 'due_date', 'progress']
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'}),
        }


    def save(self, commit=True):
        task = super(TaskRegistrationForm, self).save(commit=False)
        task.project = self.cleaned_data['project']
        task.task_name = self.cleaned_data['task_name']
        task.status = self.cleaned_data['status']
        task.progress = self.cleaned_data['progress']
        # task.due = self.cleaned_data['due']

        if commit:
            task.save()
            self.save_m2m()
            
            # Ensure 'assigns' contains valid CustomUser instances
            assigns = self.cleaned_data['assign']
            
            if isinstance(assigns, QuerySet):
                task.assign.set(assigns)
            elif isinstance(assigns, CustomUser):
                task.assign.set([assigns])
            else:
                task.assign.clear()

        return task


    def __init__(self, *args, **kwargs):
        
        user = kwargs.pop('user', None)  # Get the user from kwargs
        super(TaskRegistrationForm, self).__init__(*args, **kwargs)
        
        # Dynamic queryset based on user_type
        if user and user.user_type == 'PD':  # Project Director assigns to Scientist D
            self.fields['assign'].queryset = CustomUser.objects.filter(user_type__in=['SD', 'SC'])
        elif user and user.user_type == 'SD':  # Scientist D assigns to Scientist C
            self.fields['assign'].queryset = CustomUser.objects.filter(user_type='SC')
        else:
            self.fields['assign'].queryset = CustomUser.objects.none()
            
        # Show user email with name in assign field
        self.fields['assign'].label_from_instance = (
            lambda obj: f"{obj.get_full_name()} ({obj.email})"
        )
            
        # Add Bootstrap classes to fields
        for field_name, field in self.fields.items():
            field.widget.attrs['class'] = 'form-control'
            
        # Form field styling (Bootstrap classes)
        self.fields['project'].widget.attrs['class'] = 'form-control'
        self.fields['project'].widget.attrs['placeholder'] = 'Select Project'
        self.fields['task_name'].widget.attrs['class'] = 'form-control'
        self.fields['task_name'].widget.attrs['placeholder'] = 'Task Name'
        self.fields['status'].widget.attrs['class'] = 'form-control'
        self.fields['status'].widget.attrs['placeholder'] = 'Task Status'
        # self.fields['due'].widget.attrs['class'] = 'form-control'
        # self.fields['due'].widget.attrs['placeholder'] = 'Due Date'
        self.fields['assign'].widget.attrs['class'] = 'form-control'
        self.fields['assign'].widget.attrs['placeholder'] = 'Assign Users'
        self.fields['progress'].widget.attrs['class'] = 'form-control'
        self.fields['progress'].widget.attrs['placeholder'] = '%'

class ProjectRegistrationForm(forms.ModelForm):
    name = forms.CharField(max_length=80)
    # slug = forms.SlugField('shortcut')
    assign = forms.ModelMultipleChoiceField(queryset=CustomUser.objects.all(), required=False)
    efforts = forms.DurationField()
    status = forms.ChoiceField(choices=status)
    dead_line = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    company = forms.ModelChoiceField(queryset=Team.objects.all())
    complete_per = forms.FloatField(min_value=0, max_value=100)
    description = forms.CharField(widget=forms.Textarea)

    class Meta:
        model = Project
        fields = '__all__'


    def save(self, commit=True):
        Project = super(ProjectRegistrationForm, self).save(commit=False)
        Project.name = self.cleaned_data['name']
        Project.efforts = self.cleaned_data['efforts']
        Project.status = self.cleaned_data['status']
        Project.dead_line = self.cleaned_data['dead_line']
        Project.company = self.cleaned_data['company']
        Project.complete_per = self.cleaned_data['complete_per']
        Project.description = self.cleaned_data['description']
        # Project.slug = slugify(str(self.cleaned_data['name']))
            
        if commit:
            Project.save()
            
            # Ensure 'assigns' contains valid CustomUser instances
            assigns = self.cleaned_data['assign']
            
            if isinstance(assigns, QuerySet):
                Project.assign.set(assigns)
            elif isinstance(assigns, CustomUser):
                Project.assign.set([assigns])
            else:
                Project.assign.clear()

        return Project


    def __init__(self, *args, **kwargs):
        super(ProjectRegistrationForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['class'] = 'form-control'
        self.fields['name'].widget.attrs['placeholder'] = 'Project Name'
        self.fields['efforts'].widget.attrs['class'] = 'form-control'
        self.fields['efforts'].widget.attrs['placeholder'] = 'Efforts'
        self.fields['status'].widget.attrs['class'] = 'form-control'
        self.fields['status'].widget.attrs['placeholder'] = 'Status'
        self.fields['dead_line'].widget.attrs['class'] = 'form-control'
        self.fields['dead_line'].widget.attrs['placeholder'] = 'Dead Line, type a date'
        self.fields['company'].widget.attrs['class'] = 'form-control'
        self.fields['company'].widget.attrs['placeholder'] = 'Company'
        self.fields['complete_per'].widget.attrs['class'] = 'form-control'
        self.fields['complete_per'].widget.attrs['placeholder'] = 'Complete %'
        self.fields['description'].widget.attrs['class'] = 'form-control'
        self.fields['description'].widget.attrs['placeholder'] = 'Type here the project description...'
        self.fields['assign'].widget.attrs['class'] = 'form-control'

class SubTaskForm(forms.ModelForm):
    class Meta:
        model = SubTask
        fields = ['name', 'status', 'due_date']
        widgets = {
            'due_date': forms.DateInput(attrs={'type':'date'}),
        }
        labels = {
            'name': 'Subtask Name',
            'status': 'Subtask Status',
            'due_date': 'Subtask Due Date',
        }

SubTaskFormSet = modelformset_factory(
    SubTask,
    form=SubTaskForm,
    extra=5, # upto 5 new subtasks
    max_num = 5,
    validate_max=True,
    can_delete=False,
)