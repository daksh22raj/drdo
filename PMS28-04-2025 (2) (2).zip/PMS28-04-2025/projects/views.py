from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden, JsonResponse
from core.decorators import role_required
from django.db.models import Avg
from .models import *
from .forms import *
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.utils.timezone import now
from datetime import date, timedelta

# Create your views here.
@login_required
def projects(request):
    if request.user.user_type == 'PD':
        projects = Project.objects.all()
        avg_projects = Project.objects.all().aggregate(Avg('complete_per'))['complete_per__avg']
        tasks = Task.objects.all()
        overdue_tasks = tasks.filter(due_date__lt=now(), status__in=['Overdue'])
    elif request.user.user_type == 'SD':
        projects = Project.objects.filter(assign=request.user)
        tasks = Task.objects.filter(assign=request.user)
    else:
        return HttpResponseForbidden("You do not have permission to view this page.")
    context = {
        # 'avg_projects' : avg_projects,
        'projects' : projects,
        'tasks' : tasks,
        # 'overdue_tasks' : overdue_tasks,
    }
    return render(request, 'projects/projects.html', context)

@login_required
def newProject(request):
    if request.user.user_type == 'PD':
        if request.method == 'POST':
            form = ProjectRegistrationForm(request.POST)
            context = {'form': form}
            if form.is_valid():
                project = form.save(commit=False)
                project.created_by = request.user
                project.save()
                return redirect('projects:projects')
            else:
                return render(request, 'projects/new_project.html', {'form': form})
        
        form = ProjectRegistrationForm()
        return render(request, 'projects/new_project.html', {'form': form})
    else:
        return HttpResponseForbidden("Only Project Directors can create new projects.")

@login_required 
def edit_project(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    if request.user.user_type == 'PD' and project.created_by == request.user:
        if request.method == 'POST':
            form = ProjectRegistrationForm(request.POST, instance=project)
            if form.is_valid():
                form.save()
                return redirect('pd-dashboard' if request.user.user_type == 'PD' else 'sd-dashboard')
    else:
        form = ProjectRegistrationForm(instance=project)
        return render(request, 'projects/edit_project.html', {'form': form})
    return redirect('login')

@login_required
def delete_project(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    if request.user.user_type == 'PD' or (request.user.user_type == 'SD' and project.created_by == request.user):
        project.delete()
        return redirect('pd-dashboard' if request.user.user_type == 'PD' else 'sc-dashboard')
    return redirect('login')

# Task Management Views
@login_required
def newTask(request):
    if request.user.user_type in ['PD', 'SD']:
        if request.method == 'POST':
            form = TaskRegistrationForm(request.POST, user=request.user)
            subtask_formset = SubTaskFormSet(request.POST, queryset=SubTask.objects.none())
            if form.is_valid() and subtask_formset.is_valid():
                task = form.save()
                for subtask_form in subtask_formset:
                    if subtask_form.cleaned_data:
                        subtask = subtask_form.save(commit=False)
                        subtask.task = task
                        subtask.save()
                return redirect('projects:pd_task_list')
        else:
            form = TaskRegistrationForm(user=request.user)
            subtask_formset = SubTaskFormSet(queryset=SubTask.objects.none())
        
        return render(request, 'projects/new_task.html', {'form': form, 'subtask_formset': subtask_formset})
    else:
        return HttpResponseForbidden("You do not have permission to create tasks.")

@login_required    
def sc_tasks_list(request):
    if request.user.user_type == 'SC':
        tasks = Task.objects.filter(assign=request.user)
    else:
        tasks = Task.objects.none()

    if request.method == 'POST':
        task_id = request.POST.get("task_id")
        task = get_object_or_404(Task, id=task_id, assign=request.user)
        task.status = "Completed"
        task.save()
        return JsonResponse({"success": True, "task_id":task_id})
    context = {
        'tasks': tasks,
    }
    return render(request, 'projects/sc_task_list.html', context)

@login_required
def edit_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)

    # Only Scientist D or above can edit tasks
    if request.user.user_type not in ['SD', 'PD']:
        return render(request, 'projects/access_denied.html')
    
    if request.method == 'POST':
        form = TaskRegistrationForm(request.POST, instance=task, user=request.user)
        if form.is_valid():
            form.save()
            if request.user.user_type == 'PD':
                return redirect('pd_task_list')
            elif request.user.user_type == 'SD':
                return redirect('sd_task_list')
            # return redirect('sd_task_list')
    else:
        form = TaskRegistrationForm(instance=task, user=request.user)
    return render(request, 'projects/task_update.html', {'form': form})
                

@login_required
def task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id)

    # Ensure only assigned users can view it
    # if request.user != task.assign:
    #     return render(request, 'projects/access_denied.html')

    return render(request, 'projects/task_detail.html', {'task': task})

@login_required
def assign_task(request):
    # Only PD and SD can assign tasks
    if request.method == 'POST':
        form = TaskRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskRegistrationForm()
    return render(request, 'projects/assign_task.html', {'form': form})

@login_required
def view_team_performance(request):
    # Only PD and SD can view performance
    if request.user.user_type not in ['PD', 'SD']:
        return render(request, 'projects/access_denied.html')
    
    # PD views SD and SC performance
    if request.user.user_type == 'PD':
        tasks = Task.objects.filter(assign__user_type__in=['SD', 'SC']).distinct()
        user_types = ['SD', 'SC']
    # SD views only SC performance
    elif request.user.user_type == 'SD':
        tasks = Task.objects.filter(assign__user_type='SC').distinct()
        user_types = ['SC']
    else:
        tasks = Task.objects.none()
    
    return render(request, 'projects/team_performance.html', {'tasks': tasks, 'user_types': user_types})
    # return render(request, 'projects/team_performance.html', {'tasks': tasks})
    
# Filtered Performance by User Type
@login_required
def view_filtered_performance(request, user_type):
    # Only PD and SD can filter performance
    if request.user.user_type not in ['PD', 'SD']:
        return render(request, 'projects/access_denied.html')

    # PD can view both SD and SC
    if request.user.user_type == 'PD' and user_type in ['SD', 'SC']:
        tasks = Task.objects.filter(assign__user_type=user_type).distinct()
    # SD can only view SC performance
    elif request.user.user_type == 'SD' and user_type == 'SC':
        tasks = Task.objects.filter(assign__user_type='SC').distinct()
    else:
        tasks = Task.objects.none()

    return render(
        request,
        'projects/team_performance.html',
        {'tasks': tasks, 'filtered_user_type': user_type},
    )

@login_required
def view_my_tasks(request):
    # All users can see their own tasks
    tasks = Task.objects.filter(assigned_to=request.user)
    return render(request, 'projects/my_tasks.html', {'tasks': tasks})

@login_required
def view_task_status(request):
    # SC can only see their assigned task performance
    tasks = Task.objects.filter(assigned_to=request.user)
    return render(request, 'projects/task_status.html', {'tasks': tasks})

@login_required
def sd_task_list(request):
    if request.user.user_type not in ['SD', 'PD']:
        return render(request, 'projects/access_denied.html')

    # Scientist D can see tasks assigned to Scientist C in their team
    tasks = Task.objects.filter(assign__user_type='SC')
    
    # Update task progress dynamically if required (optional logic)
    for task in tasks:
        completed_subtasks = task.subtask_set.filter(status='Completed').count()
        total_subtasks = task.subtask_set.count()
        if total_subtasks > 0:
            task.progress = int((completed_subtasks / total_subtasks) * 100)
        else:
            task.progress = 0

    return render(request, 'projects/sd_task_list.html', {'tasks': tasks})

@login_required
def pd_task_list(request):
    # Only PD can access this view
    if request.user.user_type != 'PD':
        return render(request, 'projects/access_denied.html')
    
    # Fetch tasks assigned to SD and SC
    tasks = Task.objects.filter(assign__user_type__in=['SD', 'SC']).distinct()
    # status_filter = request.GET.get('status', '')
    # tasks = Task.objects.all()
    # if status_filter == 'overdue':
    #     tasks = [task for task in tasks if task.current_status == 'Overdue']
    # elif status_filter == 'completed':
    #     tasks = [task for task in tasks if task.current_status == 'Completed']
    # elif status_filter == 'On Due':
    #     tasks = [task for task in tasks if task.current_status == 'In Progress']
    # else:
    #     tasks = [task for task in tasks if task.current_status == 'Pending']
    
    return render(request, 'projects/pd_task_list.html', {'tasks':tasks})

# Task Detail for PD
@login_required
def pd_task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id)

    # Only PD can view task details
    if request.user.user_type != 'PD':
        return render(request, 'projects/access_denied.html')

    return render(request, 'projects/pd_task_detail.html', {'task': task})

# Edit Task for PD
@login_required
def pd_edit_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)

    # Only PD can edit tasks
    if request.user.user_type != 'PD':
        return render(request, 'projects/access_denied.html')

    if request.method == 'POST':
        form = TaskRegistrationForm(request.POST, instance=task, user=request.user)
        if form.is_valid():
            form.save()
            return redirect('projects:pd_task_list')
        else:
            print("Form errors:", form.errors)
    else:
        form = TaskRegistrationForm(instance=task, user=request.user)

    return render(request, 'projects/pd_task_update.html', {'form': form})

@login_required
def mark_task_completed(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    
    # Only assigned users or the task creator can mark it as completed
    if request.user in task.assign.all() or request.user == task.created_by:
        task.mark_as_completed()
        messages.success(request, f"Task '{task.task_name}' marked as completed.")
        return redirect('projects:task-detail', task_id=task.id)
    else:
        return HttpResponseForbidden("You do not have permission to mark this task as completed.")
    
@login_required
def red_alert_tasks(request):
    user = request.user

    if user.user_type == 'PD':
        tasks = Task.objects.filter(assign__user_type__in=['SD', 'SC']).distinct()
    elif user.user_type == 'SD':
        tasks = Task.objects.filter(assign__user_type='SC').distinct()
    elif user.user_type == 'SC':
        tasks = Task.objects.filter(assign=user)
    else:
        tasks = Task.objects.none()

    # Filter red-alert tasks
    red_alerts = [task for task in tasks if task.is_red_alert]

    return render(request, 'projects/red_alert_tasks.html', {'tasks': red_alerts})