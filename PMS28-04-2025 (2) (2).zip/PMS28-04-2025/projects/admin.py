from django.contrib import admin
from django.db import models
from django import forms
from django.utils.html import format_html
from .models import Project, Task, SubTask

# Register your models here.

class ProjectAdmin(admin.ModelAdmin):
    raw_id_fields = ('team',)
    list_display = ['name', 'team', ]
    list_filter = ['name', 'team', ]
    search_fields = ['name', 'team', 'status',]
    prepopulated_fields = {'slug':('name',)}

    class Meta:
        model = Project

class SubTaskInline(admin.TabularInline):  # or admin.StackedInline for more spacing
    model = SubTask
    extra = 5  # Show 5 empty subtask forms
    max_num = 5  # Restrict to 5 subtasks
    can_delete = True  # Allow deletion of subtasks in admin
    fields = ['name', 'status', 'due_date']
    show_change_link = True
    formfield_overrides = {
        models.CharField: {'widget': forms.TextInput(attrs={'placeholder': 'Enter subtask name'})},
        models.DateField: {'widget': forms.DateInput(attrs={'type': 'date'})},
    }
    class Media:
        js = ('static/core/js/subtask_inline.js',)  # add your custom JS file
        css = {
            'all': ('static/core/css/subtask_inline.css',)
        }
    
class SubTaskAdmin(admin.ModelAdmin):
    list_display = ['name', 'task', 'status', 'due_date']
    
class TaskAdmin(admin.ModelAdmin):
    list_display = ['task_name','project', 'status', 'progress_bar', 'due_date', 'subtask_count']
    list_filter = ['project', ]
    search_fields = ['project']
    inlines = [SubTaskInline]
    readonly_fields = ['progress_display']
    
    def progress_display(self, obj):
        if obj is None:
            return ""
        color = 'success' if obj.progress == 100 else 'info'
        return format_html(
            '<div style="width: 300px; background-color: #f0f0f0; border-radius: 5px;">'
            '  <div style="width: {}%; background-color: {}; height: 20px; border-radius: 5px; text-align: center; color: white; font-weight: bold;">{}%</div>'
            '</div>',
            obj.progress,
            '#28a745' if color == 'success' else '#17a2b8',
            obj.progress
        )
    progress_display.short_description = "Task Progress"
    
    fieldsets = (
        (None, {
            'fields': ('project', 'assign', 'assigned_team', 'task_name', 'status', 'due_date', 'progress', 'progress_display')
        }),
        ('Metadata', {
            'fields': ('last_active', 'created_by')
        }),
    )
    
    def progress_bar(self, obj):
        color = 'success' if obj.progress == 100 else 'info'
        return format_html(
            '<div style="width: 100px; background-color: #f0f0f0; border-radius: 5px;">'
            '  <div style="width: {}%; background-color: {}; height: 10px; border-radius: 5px;"></div>'
            '</div>'
            '<small>{}%</small>',
            obj.progress,
            '#28a745' if color == 'success' else '#17a2b8',
            obj.progress
        )
    progress_bar.short_description = 'Progress'
    
    def subtask_count(self, obj):
        return obj.subtask_set.count()
    subtask_count.short_description = 'No. of Subtasks'

    
class SubTaskAdmin(admin.ModelAdmin):
    list_display = ['name', 'task', 'status', 'due_date']

admin.site.register(Project, ProjectAdmin)
admin.site.register(Task, TaskAdmin)
admin.site.register(SubTask, SubTaskAdmin)