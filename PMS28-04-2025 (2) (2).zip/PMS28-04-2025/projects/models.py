from django.db import models
from datetime import date
# from django.contrib.auth.models import User
from core.models import CustomUser
from django.contrib.auth import get_user_model
from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.core.exceptions import ValidationError

User = get_user_model()

status = (
    ('Select Status', 'Select Status'),
    ('In progress', 'In progress'),
    ('Completed', 'Completed'),
)

due = (
    ('On Due', 'On Due'),
    ('Overdue', 'Overdue'),
    ('Completed', 'Completed'),
)

# Create your models here.
class Project(models.Model):
    name = models.CharField(max_length=80)
    slug = models.SlugField('shortcut', blank=True)
    assign = models.ManyToManyField(CustomUser)
    efforts = models.DurationField()
    status = models.CharField(max_length=20, choices=status, default='Select Status')
    dead_line = models.DateField()
    team = models.ForeignKey('register.Team', on_delete=models.CASCADE, related_name='projects')
    complete_per = models.FloatField(max_length=2, validators = [MinValueValidator(0), MaxValueValidator(100)])
    description = models.TextField(blank=True)

    add_date = models.DateField(auto_now_add=True)
    upd_date = models.DateField(auto_now_add=False, auto_now=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{ self.name }"


class Task(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    assign = models.ManyToManyField(CustomUser)
    assigned_team = models.ForeignKey('register.Team', null=True, blank=True, on_delete=models.CASCADE)
    task_name = models.CharField(max_length=80)
    status = models.CharField(max_length=20, choices=due, default='On Due')
    due_date = models.DateField(null=True, blank=True)
    progress = models.IntegerField(default=0) # Field for percentage
    last_active = models.DateTimeField(auto_now=True)  # Updates every time task is modified
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='created_tasks')

    class Meta:
        ordering = ['project', 'task_name']

    def __str__(self):
        return(self.task_name)
    
    def mark_as_completed(self):
        self.status = 'Completed'
        self.progress = 100
        self.save()
        
    def check_and_mark_completed(self):
        if self.subtask_set.exists() and all(sub.status == 'Completed' for sub in self.subtask_set.all()):
            self.status = 'Completed'
            self.progress = 100
            self.save()
    
    @property
    def is_red_alert(self):
        return self.due_date and date.today() > self.due_date and self.status != 'Completed'

    @property
    def current_status(self):
        if self.status == 'Completed':
            return 'Completed'
        elif self.due_date and date.today() > self.due_date:
            return 'Overdue'
        elif self.status == 'On Due':
            return 'On Due'
        else:
            return 'Pending'
    
class SubTask(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    status_choices = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed'),
    ]
    status = models.CharField(max_length=20, choices=status_choices, default='Pending')
    due_date = models.DateField(null=True, blank=True)

    def clean(self):
        if self.task and self.task.subtask_set.count() >= 5 and not self.pk:
            raise ValidationError("You can only assign up to 5 subtasks for a task.")

    def save(self, *args, **kwargs):
        self.full_clean()  # Triggers clean()
        super().save(*args, **kwargs)
        
        # After saving, check if all subtasks of the parent task are completed
        task = self.task
        if task.subtask_set.exists():
            all_completed = all(sub.status == 'Completed' for sub in task.subtask_set.all())
            if all_completed:
                task.status = 'Completed'
                task.progress = 100
                task.save()
                # self.task.check_and_mark_completed()
    def __str__(self):
        return self.name