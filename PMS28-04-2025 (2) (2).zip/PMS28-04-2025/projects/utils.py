from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.urls import reverse
from django.http import HttpResponseRedirect, JsonResponse
from core.models import CustomUser
from register.forms import RegistrationForm
from register.models import Team, Project, UserProfile
from projects.models import Task
from projects.views import *
from django.contrib.auth.decorators import login_required

def get_task_metrics(user):
    today = date.today()
    upcoming = today + timedelta(days=7)

    if user.user_type == 'PD':
        tasks = Task.objects.filter(assign__user_type__in=['SD', 'SC']).distinct()
    elif user.user_type == 'SD':
        tasks = Task.objects.filter(assign=user)
    elif user.user_type == 'SC':
        tasks = Task.objects.filter(assign=user)
    else:
        tasks = Task.objects.none()

    red_alert = [task for task in tasks if task.is_red_alert]
    completed = tasks.filter(status='2')
    upcoming_tasks = tasks.filter(due_date__gt=today, due_date__lte=upcoming, status__in=['1', '0'])
    due_passed = tasks.filter(due_date__lt=today).exclude(status='2')

    return {
        'total': tasks.count(),
        'red_alert_count': len(red_alert),
        'completed_count': completed.count(),
        'upcoming_count': upcoming_tasks.count(),
        'due_passed_count': due_passed.count(),
        'task_list': tasks,
        'red_alert_tasks': red_alert,
        'completed_tasks': completed,
        'upcoming_tasks': upcoming_tasks,
        'due_passed_tasks': due_passed,
    }