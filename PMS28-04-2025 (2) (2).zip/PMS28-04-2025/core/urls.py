from django.urls import path
from . import views
from .views import dashboard_data
from django.conf import settings
from django.conf.urls.static import static

app_name = 'core'

urlpatterns = [
    path('', views.index, name='index'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('sd-dashboard/', views.sd_dashboard, name='sd-dashboard'),
    path('sc-dashboard/', views.sc_dashboard, name='sc-dashboard'),
    path('dashboard_data/', dashboard_data, name='dashboard_data'),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)