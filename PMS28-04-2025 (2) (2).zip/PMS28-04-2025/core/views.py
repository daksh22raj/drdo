from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.urls import reverse
from django.http import HttpResponseRedirect, JsonResponse
from core.models import CustomUser
from register.forms import RegistrationForm
from register.models import Team, Project, UserProfile
from projects.models import Task
from projects.views import *
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from projects.utils import get_task_metrics
from collections import Counter

# Create your views here.
# def index(request):
#     return render(request, 'core/index.html')

User = get_user_model()

def index(request):
	context = {}  # Ensure it's a dictionary
	print("Context being passed:", context)  # Debugging Output
	try:
		return render(request, 'core/index1.html', context)
	except Exception as e:
		print("Error in rendering:", e)  # Print the exact error
		raise e  # Re-raise to see the full error traceback

@login_required
def dashboard(request):
	"""Returns JSON data for live dashboard updates."""

	User = get_user_model()
	users = User.objects.all()
	active_users = User.objects.all().filter(is_active=True)
	inactive_users = User.objects.all().filter(is_active=False)
	teams = Team.objects.all()
	projects = Project.objects.all()
	ongoing_projects = Project.objects.filter(status="In Progress")
	completed_projects = Project.objects.filter(status="Completed")
	tasks = Task.objects.all()
	pending_tasks = Task.objects.filter(status='On Due')
	completed_tasks = Task.objects.filter(status='Completed')
	overdue_tasks = Task.objects.filter(status='Overdue')
	status_counter = Counter(task.current_status for task in tasks)
	context = {
		'users' : users,
		'active_users' : active_users,
		'inactive_users': inactive_users,
		'teams' : teams,
		'projects' : projects,
		'ongoing_projects': ongoing_projects,
		'completed_projects': completed_projects,
		'tasks' : tasks,
		'pending_tasks': pending_tasks,
		'completed_tasks': completed_tasks,
		'overdue_tasks': overdue_tasks,
		'status_counts': {
			'In Progress': status_counter.get('In Progress', 0),
			'Overdue': status_counter.get('Overdue', 0),
			'Completed': status_counter.get('Completed', 0),
			'Pending': status_counter.get('Pending', 0),
		}
	}
	return render(request, 'core/dashboard.html', context)



# def login_view(request):
#     if request.method == 'POST':
#         form = AuthenticationForm(data=request.POST)
#         if form.is_valid():
#             authenticated_user = authenticate(username=request.POST['username'], password=request.POST['password'])
#             login(request, authenticated_user)
#             return redirect('core:index')
#         else:
#             return render(request, 'register/login.html', {'login_form':form})
#     else:
#         form = AuthenticationForm()
#     return render(request, 'register/login.html', {'login_form':form})

def login_view(request):
	if request.method == 'POST':
		email=request.POST['username']
		password=request.POST['password']
		
		# Authenticate user using email
		user=authenticate(request, email=email, password=password)
		
		
		if user is not None:
			login(request, user)
			
			
			if user.user_type=='PD':
				return redirect('core:dashboard')
			elif user.user_type=='SD':
				return redirect('core:sd-dashboard')
			elif user.user_type=='SC':
				return redirect('projects:sc_task_list')
			else:
				# Default redirect if user type is not recognised
				return redirect('default_dashboard')
		
		else:
			# Show error message if login fails
			return render(request, 'register/login.html', {'error': 'Invalid Credentials'})
	else:
		form = AuthenticationForm()
	return render(request, 'register/login.html', {'login_form': form})

def logout_view(request):
	logout(request)
	return HttpResponseRedirect(reverse('core:index'))


def context(request): # send context to base.html
	# if not request.session.session_key:
	#     request.session.create()
	User = get_user_model()
	users = User.objects.all()
	users_prof = UserProfile.objects.all()
	if request.user.is_authenticated:
		try:
			users_prof = UserProfile.objects.exclude(
				id=request.user.userprofile_set.values_list()[0][0])  # exclude himself from invite list
			user_id = request.user.userprofile_set.values_list()[0][0]
			logged_user = UserProfile.objects.get(id=user_id)
			friends = logged_user.friends.all()
			context = {
				'users': users,
				'users_prof': users_prof,
				'logged_user': logged_user,
				'friends' : friends,
			}
			return context
		except:
			users_prof = UserProfile.objects.all()
			context = {
				'users':users,
				'users_prof':users_prof,
			}
			return context
	else:
		context = {
			'users': users,
			'users_prof': users_prof,
		}
		return context

@login_required
def sd_dashboard(request):
	User = get_user_model()
	users = User.objects.all()
	active_users = User.objects.all().filter(is_active=True)
	projects = Project.objects.all()
	tasks = Task.objects.filter(assign=request.user)
	task_metrics = get_task_metrics(request.user)
	return render(request, 'core/sd_dashboard.html', {'projects': projects, 'tasks': tasks, 'users' : users,
		'active_users' : active_users, 'task_metrics': task_metrics})

@login_required
def sc_dashboard(request):
	tasks = Task.objects.filter(assign=request.user)
	sc_task_metrics = get_task_metrics(request.user)
	return render(request, 'core/sc_dashboard.html', {'tasks': tasks, 'sc_task_metrics': sc_task_metrics})

@login_required
def pd_dashboard(request):
	if request.user.user_type != 'PD':
		return render(request, 'projects/access_denied.html')

	context = get_task_metrics(request.user)
	return render(request, 'core/dashboard.html')

@login_required
def dashboard_data(request):

	"""Returns JSON data for live dashboard updates."""
	if request.user.user_type != "PD":
		return JsonResponse({"error": "Unauthorized"}, status=403)

	data = {
		"total_projects": Project.objects.count(),
		"ongoing_projects": Project.objects.filter(status="In Progress").count(),
		"completed_projects": Project.objects.filter(status="Completed").count(),
		"pending_tasks": Task.objects.filter(status="Pending").count(),
		"completed_tasks": Task.objects.filter(status="Completed").count(),
		"overdue_tasks": Task.objects.filter(status="Overdue").count(),
		"active_users": User.objects.filter(is_active=True).count(),
		"inactive_users": User.objects.filter(is_active=False).count(),
	}
	return JsonResponse(data)


# @login_required
# def default_dashboard(request):
#     return render(request, 'core/default_dashboard.html')

# def is_pd(user):
#     return user.groups.filter(name='ProjectDirector').exists()

# def is_sd(user):
#     return user.groups.filter(name='ScientistD').exists()

# def is_sc(user):
#     return user.groups.filter(name='ScientistC').exists()