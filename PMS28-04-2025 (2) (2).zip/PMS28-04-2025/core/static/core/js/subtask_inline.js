document.addEventListener('DOMContentLoaded', function () {
    const rows = document.querySelectorAll('.dynamic-subtask_set'); // class Django gives to inline rows
    rows.forEach((row, index) => {
        const input = row.querySelector('input[name$="-name"]');
        if (input) {
            input.placeholder = `Subtask #${index + 1}`;
        }
    });
});